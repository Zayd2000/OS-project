from os import environ
from flask import Flask, flash, g, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager, login_required, login_user, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length, ValidationError
from flask_bcrypt import Bcrypt
from flask_simpleldap import LDAP


app = Flask(__name__)
db = SQLAlchemy(app)
bcrypt = Bcrypt(app) #Used for encrypting/hashing passwords
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'thisisasecretkey' #secret key 

app.config['LDAP_HOST'] = 'ldap.example.com'
app.config['LDAP_BASE_DN'] = 'ou=Users, o=1020somekey, dc=example, dc=com'
app.config['LDAP_USERNAME'] = 'uid=ldapbindusers, ou=Users, o=1040somekey, dc=example, dc=com'
app.config['LDAP_PASSWORD'] = 'password' 


#def get_ldap_connection():
#    conn = ldap.initialize(app.config['LDAP_HOST'])
#    return conn

#SSL
LDAP_SCHEMA = environ.get('LDAP_SCHEMA', 'ldaps')
LDAP_PORT = environ.get('LDAP_PORT', 636) #Port 636/TCP = 'ldaps' port over TLS/SSL

#openLDAP
app.config['LDAP_OPENLDAP'] = True

#Users
app.config['LDAP_USER_OBJECT_FILTER'] = '(uid=%s)' #formats the user id

#Groups
app.config['LDAP_GROUP_MEMBER_FILTER'] = '(!(&(objectClass=*)(member=%s)))'
app.config['LDAP_GROUP_MEMBER_FILTER_FIELD'] = 'cn'

#Error routing
app.config['LDAP_LOGIN_VIEW'] = 'unauthorized'

ldap = LDAP(app)


login_manager = LoginManager() #Handling the login
login_manager.init_app(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False, unique=True) #username can have a max of 20 characters
    password = db.Column(db.String(80), nullable=False) #password can have a max of 80 characters


    def __init__(self, username, password):
        self.username = username

    #@staticmethod
    #def try_login(username, password):
    #    conn = get_ldap_connection()
    #    conn.simple_bind_s('cn=%s, ou=Users, dc=example, dc=com' % username, password)

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return True

#________________________________________________________________________________________________________________

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

#@app.before_request
#def get_current_user():
#    g.user = current_user

#________________________________________________________________________________________________________________

class RegisterForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(
        min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[InputRequired(), Length(
        min=4, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField("Register")

    def validate_username(self, username):
        existing_user_username = User.query.filter_by( #checks if there is an existing username in the database
            username = username.data).first()
            
        if existing_user_username:
            raise ValidationError(
                "That username already exists! Please choose a different one.")
#________________________________________________________________________________________________________________

class LoginForm(FlaskForm): #Forms to type in username/password
    username = StringField(validators=[InputRequired(), Length(
        min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[InputRequired(), Length(
        min=4, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField("Login")


@app.route("/") #routes to the root page /
def home():
    return render_template("home.html")

@app.route('/unauthorized', methods=['GET', 'POST'])
def unauthorized():
    return render_template("unauthorized.html")

@app.route("/login", methods=['GET', 'POST']) #routes to /login
def login():
    #form = LoginForm()
    #if form.validate_on_submit():
    #    user = User.query.filter_by(username = form.username.data).first()
        
    #    if user:
    #        if bcrypt.check_password_hash(user.password, form.password.data):
    #            login_user(user)
    #            return redirect(url_for('dashboard'))
    #    else:
    #        logout_user()
    #        return redirect(url_for('unauthorized'))
    #return render_template('login.html', form=form)

    form = LoginForm(request.form)

    if request.method == 'POST' and form.validate_on_submit():
        username = request.form.get('username')
        password = request.form.get('password')
            
        user = User.query.filter_by(username=form.username.data).first()

        if user:
            if bcrypt.check_password_hash(user.password, form.password.data):
                login_user(user)
                return redirect(url_for('dashboard'))
        else:
            logout_user()
            return redirect(url_for('unauthorized'))
        
    return render_template('login.html', form=form)

@app.route('/dashboard', methods=['GET', 'POST']) #routes to /dashboard
def dashboard():
    return render_template('dashboard.html')


@app.route('/logout', methods=['GET', 'POST']) #routes to /logout
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


@app.route("/register", methods=['GET', 'POST']) #routes to /register
def register():
    form = RegisterForm()

    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, password=hashed_password)
        db.session.add(new_user)
        #db.session.commit() #Very glitchy.

        return redirect(url_for('login'))

    return render_template("register.html", form=form)

if __name__ == "__main__":
    app.run()